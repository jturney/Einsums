
    Copyright (c) The Einsums Developers. All rights reserved.
    Licensed under the MIT License. See LICENSE.txt in the project root for license information.

.. _modules_errors:

======
errors
======

TODO: High-level description of the module.

See the :ref:`API reference <modules_errors_api>` of this module for more
details.

